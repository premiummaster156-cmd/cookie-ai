import type { Metadata } from 'next'
import { GeistSans, GeistMono } from 'geist/font/sans'
import './globals.css'

export const metadata: Metadata = {
  title: 'Cookie',
  description: 'A calm, capable AI workspace.',
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${GeistSans.variable} ${GeistMono.variable}`}>
      <body>{children}</body>
    </html>
  )
}
