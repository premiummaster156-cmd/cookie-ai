'use client'

import { useMemo, useState } from 'react'

type View = 'chat' | 'search' | 'settings' | 'profile' | 'usage' | 'upgrade' | 'help'
type IconName =
  | 'menu' | 'plus' | 'search' | 'chat' | 'settings' | 'user' | 'chart'
  | 'spark' | 'help' | 'send' | 'attach' | 'sliders' | 'chevron' | 'close'
  | 'check' | 'lock' | 'database' | 'bell' | 'shield' | 'keyboard' | 'trash'
  | 'copy' | 'more' | 'arrow'

type Message = { id: number; role: 'user' | 'assistant'; text: string; time: string }
type Chat = { id: number; title: string; date: string; pinned?: boolean }

const chats: Chat[] = [
  { id: 1, title: 'Help me plan a trip', date: 'Today', pinned: true },
  { id: 2, title: 'Explain quantum computing', date: 'Today' },
  { id: 3, title: 'Python debugging', date: 'Yesterday' },
  { id: 4, title: 'Rewrite this email', date: 'Yesterday' },
  { id: 5, title: 'Ideas for a new project', date: 'Monday' },
  { id: 6, title: 'Study notes and summary', date: 'Monday' },
  { id: 7, title: 'Compare two approaches', date: 'Sunday' },
  { id: 8, title: 'Short story opening', date: 'Sunday' },
  { id: 9, title: 'Budget planning', date: 'Sunday' },
  { id: 10, title: 'Learn TypeScript', date: 'Saturday' },
]

const models = [
  { id: 'cookie-120b', name: 'Cookie 120B', description: 'General-purpose model', badge: 'Current' },
  { id: 'cookie-fast', name: 'Cookie Fast', description: 'Faster everyday responses', badge: 'Fast' },
  { id: 'cookie-reason', name: 'Cookie Reason', description: 'Deeper reasoning for difficult tasks', badge: 'Pro' },
]

const suggestions = [
  ['Write', 'Draft an email, post, or idea', 'Help me write a clear email about '],
  ['Learn', 'Explain a topic simply', 'Explain this topic clearly: '],
  ['Code', 'Build or debug something', 'Help me debug this code: '],
  ['Think', 'Work through a difficult problem', 'Help me reason through this problem: '],
]

const faqs = [
  ['What is Cookie?', 'Cookie is an AI workspace for conversation, writing, research, coding, learning, and everyday tasks.'],
  ['Which model does Cookie use?', 'The model selector is ready for secure server-side model routing. Model credentials should never be exposed to the browser.'],
  ['Will my chats be saved?', 'The interface is structured for persistent conversations. Authentication and database persistence can be connected without changing the visual shell.'],
  ['How do plans work?', 'Free, Plus, and Pro provide different limits and model access. Entitlements should be enforced on the backend.'],
  ['Can I use Cookie on my phone?', 'Yes. The layout uses a mobile drawer, compact header, large touch targets, and a composer designed for small screens.'],
  ['Can I change the appearance?', 'Yes. Appearance controls are included in Settings, with Cookie brown and cream as the default visual language.'],
]

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  const p = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, 'aria-hidden': true }
  switch (name) {
    case 'menu': return <svg {...p}><path d="M4 6h16M4 12h16M4 18h16"/></svg>
    case 'plus': return <svg {...p}><path d="M12 5v14M5 12h14"/></svg>
    case 'search': return <svg {...p}><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4.2 4.2"/></svg>
    case 'chat': return <svg {...p}><path d="M5 5.5h14a2 2 0 0 1 2 2v8.2a2 2 0 0 1-2 2H11l-5.2 3v-3H5a2 2 0 0 1-2-2V7.5a2 2 0 0 1 2-2Z"/></svg>
    case 'settings': return <svg {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.8 1.8 0 0 0 .4 2l.1.1-2.5 2.5-.1-.1a1.8 1.8 0 0 0-2-.4 1.8 1.8 0 0 0-1.1 1.7v.2H10v-.2a1.8 1.8 0 0 0-1.1-1.7 1.8 1.8 0 0 0-2 .4l-.1.1-2.5-2.5.1-.1a1.8 1.8 0 0 0 .4-2A1.8 1.8 0 0 0 3.1 14H3v-3h.1a1.8 1.8 0 0 0 1.7-1.1 1.8 1.8 0 0 0-.4-2l-.1-.1 2.5-2.5.1.1a1.8 1.8 0 0 0 2 .4A1.8 1.8 0 0 0 10 4.1V4h3v.1a1.8 1.8 0 0 0 1.1 1.7 1.8 1.8 0 0 0 2-.4l.1-.1 2.5 2.5-.1.1a1.8 1.8 0 0 0-.4 2 1.8 1.8 0 0 0 1.7 1.1h.1v3h-.1a1.8 1.8 0 0 0-1.7 1.1Z"/></svg>
    case 'user': return <svg {...p}><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.8-3.3 3.2-5 7-5s6.2 1.7 7 5"/></svg>
    case 'chart': return <svg {...p}><path d="M5 20V10M12 20V4M19 20v-7"/></svg>
    case 'spark': return <svg {...p}><path d="m12 3 1.6 5.4L19 10l-5.4 1.6L12 17l-1.6-5.4L5 10l5.4-1.6L12 3ZM19 16l.7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7L19 16Z"/></svg>
    case 'help': return <svg {...p}><circle cx="12" cy="12" r="9"/><path d="M9.7 9a2.4 2.4 0 1 1 4.4 1.3c-.7.9-2.1 1.2-2.1 2.7M12 16.4h.01"/></svg>
    case 'send': return <svg {...p}><path d="m4 4 16 8-16 8 3.1-8L4 4Z"/><path d="M7.2 12H20"/></svg>
    case 'attach': return <svg {...p}><path d="m9.5 12.5 5.9-5.9a3.2 3.2 0 0 1 4.5 4.5l-7.2 7.2a4.8 4.8 0 1 1-6.8-6.8l7-7"/></svg>
    case 'sliders': return <svg {...p}><path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h9M17 18h3"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="15" cy="18" r="2"/></svg>
    case 'chevron': return <svg {...p}><path d="m9 18 6-6-6-6"/></svg>
    case 'close': return <svg {...p}><path d="m6 6 12 12M18 6 6 18"/></svg>
    case 'check': return <svg {...p}><path d="m5 12 4.3 4.3L19 7"/></svg>
    case 'lock': return <svg {...p}><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
    case 'database': return <svg {...p}><ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v6c0 1.7 3.1 3 7 3s7-1.3 7-3V6M5 12v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/></svg>
    case 'bell': return <svg {...p}><path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></svg>
    case 'shield': return <svg {...p}><path d="M12 3 20 6v5c0 5-3.3 8.3-8 10-4.7-1.7-8-5-8-10V6l8-3Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/></svg>
    case 'keyboard': return <svg {...p}><rect x="3" y="6" width="18" height="12" rx="2"/><path d="M6 10h.01M9 10h.01M12 10h.01M15 10h.01M18 10h.01M6 14h8M16 14h2"/></svg>
    case 'trash': return <svg {...p}><path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13M10 11v5M14 11v5"/></svg>
    case 'copy': return <svg {...p}><rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/></svg>
    case 'more': return <svg {...p}><circle cx="5" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1" fill="currentColor" stroke="none"/></svg>
    case 'arrow': return <svg {...p}><path d="M5 12h14M13 6l6 6-6 6"/></svg>
  }
}

function CookieMark({ small = false }: { small?: boolean }) {
  return <span className={`cookie-mark${small ? ' small' : ''}`}><i/><i/><i/></span>
}

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: () => void; label: string }) {
  return <button type="button" className={`toggle ${checked ? 'on' : ''}`} aria-label={label} aria-pressed={checked} onClick={onChange}><span/></button>
}

export default function Home() {
  const [view, setView] = useState<View>('chat')
  const [mobile, setMobile] = useState(false)
  const [modelOpen, setModelOpen] = useState(false)
  const [model, setModel] = useState(models[0])
  const [text, setText] = useState('')
  const [messages, setMessages] = useState<Message[]>([])
  const [query, setQuery] = useState('')
  const [theme, setTheme] = useState<'dark' | 'light' | 'system'>('dark')
  const [enterToSend, setEnterToSend] = useState(true)
  const [history, setHistory] = useState(true)
  const [modelNames, setModelNames] = useState(true)
  const [notifications, setNotifications] = useState(true)
  const [name, setName] = useState('Dilnoza')
  const [email, setEmail] = useState('you@example.com')
  const [saved, setSaved] = useState(false)
  const [faq, setFaq] = useState<number | null>(null)
  const [toast, setToast] = useState('')

  const results = useMemo(() => chats.filter(c => c.title.toLowerCase().includes(query.toLowerCase())), [query])

  const go = (next: View) => {
    setView(next)
    setMobile(false)
    setModelOpen(false)
  }

  const toastMessage = (message: string) => {
    setToast(message)
    window.setTimeout(() => setToast(''), 2200)
  }

  const send = () => {
    const value = text.trim()
    if (!value) return
    const now = new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
    setMessages(prev => [...prev,
      { id: Date.now(), role: 'user', text: value, time: now },
      { id: Date.now() + 1, role: 'assistant', text: 'The Cookie frontend is ready. The production model connection will be added through the secure backend layer.', time: now },
    ])
    setText('')
  }

  const keyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (enterToSend && event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault()
      send()
    }
  }

  return (
    <div className={`cookie-app ${theme === 'light' ? 'light-theme' : ''}`}>
      {mobile && <button className="scrim" aria-label="Close navigation" onClick={() => setMobile(false)}/>}
      <aside className={`sidebar ${mobile ? 'open' : ''}`}>
        <div className="sidebar-header">
          <button className="brand" onClick={() => go('chat')}><CookieMark small/><span>Cookie</span></button>
          <button className="close-mobile" onClick={() => setMobile(false)} aria-label="Close menu"><Icon name="close"/></button>
        </div>
        <button className="new-chat" onClick={() => { setMessages([]); setText(''); go('chat') }}><Icon name="plus" size={17}/><span>New chat</span><kbd>⌘ K</kbd></button>
        <nav className="nav-main">
          <button className={view === 'chat' ? 'active' : ''} onClick={() => go('chat')}><Icon name="chat"/><span>Chat</span></button>
          <button className={view === 'search' ? 'active' : ''} onClick={() => go('search')}><Icon name="search"/><span>Search</span><kbd>⌘ /</kbd></button>
        </nav>
        <div className="recent-title"><span>Recent</span><button aria-label="Recent chat options"><Icon name="more" size={16}/></button></div>
        <div className="recent">
          {history ? chats.map(chat => <button key={chat.id} onClick={() => go('chat')}><span>{chat.title}</span>{chat.pinned && <i/>}</button>) : <p className="history-off">Chat history is off.</p>}
        </div>
        <div className="sidebar-grow"/>
        <button className="upgrade-mini" onClick={() => go('upgrade')}><span><Icon name="spark" size={15}/></span><strong>Get more with Plus<small>Higher limits and premium models</small></strong><Icon name="chevron" size={15}/></button>
        <div className="account-rule"/>
        <button className="account" onClick={() => go('profile')}><span className="avatar">D</span><span><strong>{name}</strong><small>Free plan</small></span><Icon name="more" size={16}/></button>
      </aside>

      <main className="main">
        <header className="topbar">
          <button className="mobile-menu" onClick={() => setMobile(true)} aria-label="Open menu"><Icon name="menu"/></button>
          <button className="mobile-brand" onClick={() => go('chat')}><CookieMark small/><strong>Cookie</strong></button>
          <div className="model-wrap">
            <button className={`model-button ${modelOpen ? 'open' : ''}`} onClick={() => setModelOpen(!modelOpen)} aria-expanded={modelOpen}>{modelNames ? model.name : 'Model'}<Icon name="chevron" size={15}/></button>
            {modelOpen && <div className="model-menu">
              <div className="model-heading"><span>Choose a model</span><Icon name="sliders" size={15}/></div>
              {models.map(option => <button key={option.id} className={model.id === option.id ? 'selected' : ''} onClick={() => { setModel(option); setModelOpen(false); toastMessage(`${option.name} selected`) }}><span><strong>{option.name}</strong><small>{option.description}</small></span><em>{option.badge}</em>{model.id === option.id && <Icon name="check" size={15}/>}</button>)}
              <div className="model-foot"><Icon name="lock" size={14}/><span>Model access follows your plan.</span></div>
            </div>}
          </div>
          <button className="top-avatar" onClick={() => go('profile')} aria-label="Profile">D</button>
        </header>

        {view === 'chat' && <ChatView messages={messages} text={text} setText={setText} send={send} keyDown={keyDown} model={model} setTextFromSuggestion={value => { setText(value); setTimeout(() => document.getElementById('composer')?.focus(), 0) }}/>}
        {view === 'search' && <SearchView query={query} setQuery={setQuery} results={results} openChat={() => go('chat')}/>}
        {view === 'settings' && <SettingsView theme={theme} setTheme={setTheme} enterToSend={enterToSend} setEnterToSend={setEnterToSend} history={history} setHistory={setHistory} modelNames={modelNames} setModelNames={setModelNames} notifications={notifications} setNotifications={setNotifications} toast={toastMessage}/>}
        {view === 'profile' && <ProfileView name={name} setName={setName} email={email} setEmail={setEmail} saved={saved} save={() => { setSaved(true); toastMessage('Profile saved') }}/>}
        {view === 'usage' && <UsageView go={go}/>}
        {view === 'upgrade' && <UpgradeView go={go} toast={toastMessage}/>}
        {view === 'help' && <HelpView faq={faq} setFaq={setFaq}/>}

        <nav className="bottom-nav">
          <button className={view === 'chat' ? 'active' : ''} onClick={() => go('chat')}><Icon name="chat"/><span>Chat</span></button>
          <button className={view === 'search' ? 'active' : ''} onClick={() => go('search')}><Icon name="search"/><span>Search</span></button>
          <button className={view === 'settings' ? 'active' : ''} onClick={() => go('settings')}><Icon name="settings"/><span>Settings</span></button>
          <button className={view === 'profile' ? 'active' : ''} onClick={() => go('profile')}><Icon name="user"/><span>Profile</span></button>
        </nav>
        {toast && <div className="toast">{toast}</div>}
      </main>
    </div>
  )
}

function ChatView({ messages, text, setText, send, keyDown, model, setTextFromSuggestion }: {
  messages: Message[]; text: string; setText: (v: string) => void; send: () => void; keyDown: (e: React.KeyboardEvent<HTMLTextAreaElement>) => void; model: typeof models[number]; setTextFromSuggestion: (v: string) => void
}) {
  return <section className="chat-page">
    {messages.length === 0 ? <div className="welcome">
      <CookieMark/>
      <h1>How can I help?</h1>
      <p>Ask anything, write something, or work through a problem.</p>
      <div className="suggestions">{suggestions.map(([title, detail, prompt]) => <button key={title} onClick={() => setTextFromSuggestion(prompt)}><strong>{title}</strong><span>{detail}</span></button>)}</div>
    </div> : <div className="conversation">
      <div className="conversation-title"><span>New conversation</span><button aria-label="Conversation options"><Icon name="more"/></button></div>
      <div className="messages">{messages.map(message => <MessageRow key={message.id} message={message}/>)}</div>
    </div>}
    <div className="composer-area">
      <div className="composer">
        <textarea id="composer" value={text} onChange={e => setText(e.target.value)} onKeyDown={keyDown} placeholder="Message Cookie" aria-label="Message Cookie"/>
        <div className="composer-row">
          <div><button aria-label="Attach file"><Icon name="attach" size={18}/></button><button className="tools"><Icon name="sliders" size={16}/><span>Tools</span></button></div>
          <div className="composer-right"><span>{model.name}</span><button className={text.trim() ? 'send ready' : 'send'} onClick={send} aria-label="Send"><Icon name="send" size={16}/></button></div>
        </div>
      </div>
      <p>Cookie can make mistakes. Check important information.</p>
    </div>
  </section>
}

function MessageRow({ message }: { message: Message }) {
  const [copied, setCopied] = useState(false)
  return <article className={`message ${message.role}`}>
    <div className={`message-avatar ${message.role}`}>{message.role === 'assistant' ? <CookieMark small/> : 'D'}</div>
    <div className="message-body">
      <div className="message-meta"><strong>{message.role === 'assistant' ? 'Cookie' : 'You'}</strong><span>{message.time}</span></div>
      <p>{message.text}</p>
      {message.role === 'assistant' && <div className="message-actions"><button onClick={() => { navigator.clipboard?.writeText(message.text); setCopied(true); setTimeout(() => setCopied(false), 1200) }}><Icon name="copy" size={14}/>{copied ? 'Copied' : 'Copy'}</button><button><Icon name="more" size={14}/></button></div>}
    </div>
  </article>
}

function SearchView({ query, setQuery, results, openChat }: { query: string; setQuery: (v: string) => void; results: Chat[]; openChat: () => void }) {
  return <Page title="Search" description="Find a conversation and pick up where you left off.">
    <div className="search-box"><Icon name="search"/><input autoFocus value={query} onChange={e => setQuery(e.target.value)} placeholder="Search chats"/><kbd>⌘ /</kbd></div>
    <div className="search-list">{results.length ? results.map(chat => <button key={chat.id} onClick={openChat}><span className="result-icon"><Icon name="chat" size={16}/></span><span><strong>{chat.title}</strong><small>{chat.date} · Conversation</small></span><Icon name="chevron" size={16}/></button>) : <div className="empty"><Icon name="search" size={26}/><h2>No conversations found</h2><p>Try another search term.</p></div>}</div>
  </Page>
}

function SettingsView({ theme, setTheme, enterToSend, setEnterToSend, history, setHistory, modelNames, setModelNames, notifications, setNotifications, toast }: any) {
  return <Page title="Settings" description="Manage your Cookie experience and preferences.">
    <div className="settings-layout">
      <aside className="settings-tabs"><button className="active">General</button><button>Appearance</button><button>Notifications</button><button>Data controls</button></aside>
      <div className="settings-content">
        <Group title="Appearance" description="Keep Cookie comfortable and focused.">
          <Row icon="sliders" title="Theme" description="Choose how the interface appears on this device."><select value={theme} onChange={e => setTheme(e.target.value)}><option value="dark">Dark</option><option value="light">Light</option><option value="system">System</option></select></Row>
          <Row icon="spark" title="Cookie accent" description="A restrained warm accent for focus and primary actions."><span className="accent"><i/>Cookie orange</span></Row>
          <Row icon="chat" title="Show model names" description="Display the active model in the header and composer."><Toggle checked={modelNames} onChange={() => setModelNames(!modelNames)} label="Show model names"/></Row>
        </Group>
        <Group title="Chat" description="Control how conversations behave.">
          <Row icon="keyboard" title="Send with Enter" description="Press Enter to send. Use Shift + Enter for a new line."><Toggle checked={enterToSend} onChange={() => setEnterToSend(!enterToSend)} label="Send with Enter"/></Row>
          <Row icon="database" title="Chat history" description="Keep conversations available in the recent list."><Toggle checked={history} onChange={() => setHistory(!history)} label="Chat history"/></Row>
        </Group>
        <Group title="Notifications" description="Choose what Cookie can surface."><Row icon="bell" title="Product notifications" description="Receive product and account updates when connected."><Toggle checked={notifications} onChange={() => setNotifications(!notifications)} label="Notifications"/></Row></Group>
        <Group title="Privacy & security" description="Controls for the production data layer.">
          <Row icon="shield" title="Account security" description="Authentication and sessions will be handled server-side."><button className="row-link" onClick={() => toast('Security settings will connect to authentication')}>Manage <Icon name="chevron" size={15}/></button></Row>
          <Row icon="lock" title="Model privacy" description="Model credentials belong on the server, never in the browser."><span className="protected"><i/>Protected</span></Row>
        </Group>
        <Group title="Data controls" description="Destructive actions require server authorization in production."><Row icon="trash" title="Delete all conversations" description="Permanently remove your stored chat history."><button className="danger" onClick={() => toast('No conversations were deleted in the frontend prototype')}>Delete all</button></Row></Group>
      </div>
    </div>
  </Page>
}

function Group({ title, description, children }: { title: string; description: string; children: React.ReactNode }) {
  return <section className="group"><div className="group-title"><h2>{title}</h2><p>{description}</p></div><div className="group-rows">{children}</div></section>
}

function Row({ icon, title, description, children }: { icon: IconName; title: string; description: string; children: React.ReactNode }) {
  return <div className="setting-row"><div className="setting-label"><span><Icon name={icon} size={17}/></span><div><strong>{title}</strong><small>{description}</small></div></div><div className="setting-control">{children}</div></div>
}

function ProfileView({ name, setName, email, setEmail, saved, save }: any) {
  return <Page title="Profile" description="Manage the identity shown across your Cookie account.">
    <div className="profile-layout">
      <section className="profile-card"><div className="identity"><div className="profile-avatar">D</div><div><h2>{name || 'Your profile'}</h2><p>Free plan · Account owner</p></div></div>
        <div className="form-grid"><label>Display name<input value={name} onChange={e => setName(e.target.value)}/></label><label>Email address<input value={email} onChange={e => setEmail(e.target.value)}/></label></div>
        <div className="profile-buttons"><button className="primary" onClick={save}>{saved ? <><Icon name="check" size={15}/>Saved</> : 'Save changes'}</button><button className="secondary">Security</button></div>
      </section>
      <aside className="side-card"><span>PLAN</span><strong>Free</strong><p>20 messages per day in the current product configuration.</p><button className="text-button">View plans <Icon name="arrow" size={14}/></button><hr/><span>ACCOUNT</span><strong>Protected</strong><p>Production authentication will be handled securely by the backend.</p></aside>
    </div>
  </Page>
}

function UsageView({ go }: { go: (v: View) => void }) {
  return <Page title="Usage" description="A clear view of your current limits and plan.">
    <div className="usage-grid"><section className="usage-card"><span className="eyebrow">MESSAGES TODAY</span><strong>12 <small>/ 20</small></strong><div className="progress"><i/></div><div className="usage-foot"><span>8 remaining</span><span>60% used</span></div></section><section className="usage-promo"><span><Icon name="spark"/></span><h2>Need more room?</h2><p>Paid plans can raise message limits and unlock premium models when billing is connected.</p><button className="primary" onClick={() => go('upgrade')}>View plans</button></section></div>
    <div className="usage-table"><div className="table-head"><span>Plan</span><span>Messages</span><span>Models</span><span>Tools</span></div><div className="table-row current"><strong>Free<small>Current plan</small></strong><span>20 / day</span><span>Cookie</span><span>Core</span></div><div className="table-row"><strong>Plus<small>Regular work</small></strong><span>Higher</span><span>Premium</span><span>More</span></div><div className="table-row"><strong>Pro<small>Demanding projects</small></strong><span>Highest</span><span>Advanced</span><span>Expanded</span></div></div>
  </Page>
}

function UpgradeView({ go, toast }: { go: (v: View) => void; toast: (s: string) => void }) {
  const plans = [
    ['Free', '$0', 'For trying Cookie and everyday questions.', ['20 messages per day', 'Cookie model', 'Chat history', 'Core tools'], true, false],
    ['Plus', '$—', 'For regular work and longer conversations.', ['Higher message limits', 'Premium models', 'Priority access', 'More tools'], false, true],
    ['Pro', '$—', 'For demanding projects and advanced use.', ['Highest limits', 'Advanced models', 'Expanded tools', 'Priority capacity'], false, false],
  ]
  return <Page title="Upgrade" description="Choose the amount of access that fits the way you work.">
    <div className="upgrade-intro"><span className="eyebrow">COOKIE PLANS</span><h2>More room for your work.</h2><p>The plan system stays simple. Exact billing and model availability can be connected when the backend is ready.</p></div>
    <div className="plans">{plans.map(([name, price, desc, features, current, featured]) => <article className={`plan ${featured ? 'featured' : ''}`} key={String(name)}>{featured && <em>Most flexible</em>}<h2>{name}</h2><p>{desc}</p><strong>{price}<small> / month</small></strong><ul>{(features as string[]).map(f => <li key={f}><Icon name="check" size={15}/>{f}</li>)}</ul><button className={current ? 'secondary' : featured ? 'primary' : 'secondary'} onClick={() => current ? go('chat') : toast(`${name} billing will be available later`)}>{current ? 'Current plan' : 'Coming soon'}</button></article>)}</div>
    <p className="billing-note"><Icon name="lock" size={14}/> Payments and subscription state belong on the server.</p>
  </Page>
}

function HelpView({ faq, setFaq }: { faq: number | null; setFaq: (v: number | null) => void }) {
  return <Page title="Help" description="Straightforward answers about Cookie."><div className="help-layout"><div className="faq">{faqs.map(([q, a], i) => <div className={`faq-item ${faq === i ? 'open' : ''}`} key={q}><button onClick={() => setFaq(faq === i ? null : i)}><span>{q}</span><Icon name="chevron" size={17}/></button>{faq === i && <p>{a}</p>}</div>)}</div><aside className="support"><span><Icon name="help"/></span><h2>Still need help?</h2><p>Support will connect to a real channel when the account backend is in place.</p><button className="text-button">Contact support <Icon name="arrow" size={14}/></button></aside></div></Page>
}

function Page({ title, description, children }: { title: string; description: string; children: React.ReactNode }) {
  return <section className="page"><div className="page-inner"><header><h1>{title}</h1><p>{description}</p></header>{children}</div></section>
}

/*
COOKIE PRODUCT CONTRACT
1. The browser never receives an Ollama secret.
2. Model access is checked server-side.
3. Usage counters are advisory in the frontend and authoritative in the backend.
4. Conversation ownership is checked against the authenticated user.
5. Delete operations require authenticated authorization.
6. Search should be backed by indexed conversation data in production.
7. Streaming can be added without changing the composer structure.
8. Billing state is never trusted from client state.
9. Plan features are descriptive UI until server entitlements exist.
10. Error messages should be concise and recoverable.
11. Loading states should preserve layout dimensions.
12. Network retries should be bounded.
13. The backend should log model latency and usage separately.
14. The UI should not expose provider-specific credentials.
15. The frontend can remain static while the backend evolves.
16. The model picker should disable unavailable models.
17. The usage page should consume server-calculated limits.
18. The profile page should consume authenticated account data.
19. Settings should persist through a user preference endpoint.
20. Chat history should use stable conversation IDs.
21. Messages should have stable IDs.
22. The assistant stream should support cancellation.
23. The composer should support multiline input.
24. Attachments should be validated before upload.
25. Attachment permissions should be server-side.
26. Moderation rules should run before provider calls when required.
27. Provider errors should not leak internal secrets.
28. Database errors should not expose SQL details.
29. Rate limits should be independent of UI counters.
30. The product shell should remain usable without animations.
31. Accessibility states should not depend on color alone.
32. Focus should remain visible on keyboard navigation.
33. Mobile navigation should close after route selection.
34. The account menu should remain reachable on small screens.
35. The sidebar should not dominate the conversation area.
36. The composer should remain visually stable when text grows.
37. The main content should have a readable maximum width.
38. Secondary text should maintain sufficient contrast.
39. Primary actions should not be oversized.
40. Decorative effects should not compete with content.
41. The brand mark is a CSS shape, not an emoji.
42. UI icons are inline SVGs.
43. No icon should depend on an external image host.
44. No external font request is needed when Geist is bundled.
45. Page-level headings should be unique.
46. Buttons should use button semantics.
47. Links should be used for actual navigation when appropriate.
48. Form labels should describe their controls.
49. Destructive actions should be visually distinct.
50. Confirmation should be added before irreversible production deletion.
51. Search empty states should explain what to do next.
52. Upgrade copy should avoid fake urgency.
53. Usage numbers should be clearly labeled.
54. Pricing placeholders should not imply a real charge.
55. Product availability should be explicit.
56. Model names should be server-configurable.
57. The interface should remain calm under dense content.
58. The sidebar should not use decorative gradients.
59. Cards should use borders and spacing rather than glass effects.
60. The visual system should be consistent across every product surface.
*/
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -41.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -41.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -41.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -41.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -40.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -40.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -40.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -40.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -40.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -40.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -40.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -40.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -40.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -40.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -40.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -40.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -40.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -40.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -40.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -40.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -40.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -40.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -40.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -40.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -39.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -39.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -39.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -39.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -39.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -39.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -39.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -39.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -39.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -39.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -39.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -39.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -39.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -39.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -39.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -39.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -39.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -39.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -39.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -39.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -38.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -38.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -38.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -38.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -38.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -38.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -38.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -38.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -38.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -38.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -38.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -38.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -38.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -38.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -38.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -38.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -38.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -38.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -38.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -38.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -37.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -37.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -37.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -37.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -37.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -37.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -37.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -37.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -37.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -37.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -37.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -37.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -37.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -37.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -37.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -37.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -37.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -37.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -37.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -37.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -36.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -36.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -36.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -36.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -36.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -36.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -36.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -36.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -36.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -36.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -36.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -36.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -36.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -36.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -36.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -36.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -36.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -36.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -36.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -36.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -35.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -35.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -35.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -35.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -35.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -35.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -35.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -35.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -35.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -35.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -35.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -35.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -35.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -35.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -35.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -35.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -35.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -35.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -35.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -35.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -34.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -34.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -34.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -34.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -34.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -34.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -34.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -34.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -34.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -34.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -34.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -34.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -34.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -34.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -34.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -34.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -34.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -34.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -34.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -34.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -33.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -33.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -33.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -33.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -33.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -33.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -33.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -33.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -33.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -33.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -33.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -33.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -33.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -33.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -33.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -33.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -33.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -33.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -33.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -33.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -32.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -32.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -32.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -32.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -32.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -32.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -32.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -32.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -32.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -32.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -32.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -32.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -32.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -32.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -32.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -32.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -32.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -32.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -32.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -32.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -31.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -31.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -31.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -31.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -31.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -31.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -31.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -31.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -31.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -31.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -31.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -31.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -31.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -31.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -31.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -31.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -31.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -31.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -31.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -31.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -30.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -30.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -30.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -30.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -30.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -30.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -30.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -30.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -30.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -30.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -30.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -30.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -30.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -30.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -30.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -30.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -30.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -30.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -30.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -30.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -29.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -29.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -29.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -29.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -29.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -29.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -29.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -29.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -29.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -29.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -29.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -29.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -29.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -29.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -29.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -29.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -29.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -29.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -29.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -29.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -28.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -28.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -28.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -28.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -28.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -28.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -28.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -28.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -28.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -28.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -28.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -28.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -28.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -28.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -28.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -28.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -28.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -28.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -28.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -28.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -27.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -27.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -27.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -27.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -27.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -27.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -27.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -27.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -27.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -27.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -27.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -27.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -27.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -27.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -27.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -27.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -27.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -27.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -27.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -27.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -26.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -26.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -26.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -26.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -26.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -26.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -26.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -26.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -26.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -26.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -26.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -26.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -26.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -26.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -26.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -26.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -26.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -26.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -26.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -26.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -25.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -25.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -25.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -25.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -25.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -25.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -25.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -25.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -25.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -25.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -25.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -25.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -25.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -25.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -25.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -25.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -25.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -25.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -25.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -25.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -24.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -24.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -24.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -24.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -24.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -24.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -24.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -24.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -24.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -24.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -24.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -24.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -24.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -24.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -24.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -24.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -24.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -24.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -24.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -24.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -23.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -23.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -23.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -23.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -23.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -23.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -23.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -23.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -23.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -23.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -23.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -23.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -23.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -23.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -23.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -23.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -23.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -23.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -23.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -23.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -22.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -22.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -22.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -22.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -22.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -22.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -22.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -22.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -22.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -22.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -22.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -22.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -22.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -22.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -22.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -22.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -22.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -22.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -22.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -22.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -21.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -21.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -21.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -21.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -21.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -21.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -21.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -21.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -21.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -21.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -21.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -21.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -21.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -21.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -21.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -21.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -21.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -21.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -21.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -21.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -20.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -20.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -20.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -20.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -20.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -20.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -20.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -20.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -20.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -20.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -20.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -20.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -20.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -20.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -20.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -20.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -20.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -20.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -20.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -20.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -19.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -19.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -19.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -19.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -19.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -19.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -19.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -19.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -19.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -19.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -19.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -19.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -19.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -19.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -19.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -19.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -19.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -19.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -19.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -19.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -18.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -18.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -18.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -18.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -18.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -18.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -18.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -18.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -18.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -18.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -18.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -18.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -18.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -18.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -18.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -18.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -18.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -18.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -18.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -18.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -17.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -17.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -17.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -17.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -17.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -17.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -17.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -17.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -17.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -17.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -17.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -17.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -17.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -17.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -17.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -17.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -17.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -17.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -17.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -17.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -16.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -16.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -16.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -16.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -16.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -16.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -16.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -16.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -16.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -16.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -16.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -16.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -16.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -16.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -16.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -16.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -16.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -16.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -16.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -16.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -15.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -15.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -15.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -15.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -15.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -15.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -15.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -15.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -15.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -15.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -15.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -15.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -15.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -15.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -15.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -15.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -15.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -15.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -15.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -15.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -14.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -14.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -14.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -14.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -14.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -14.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -14.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -14.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -14.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -14.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -14.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -14.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -14.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -14.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -14.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -14.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -14.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -14.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -14.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -14.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -13.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -13.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -13.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -13.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -13.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -13.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -13.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -13.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -13.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -13.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -13.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -13.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -13.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -13.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -13.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -13.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -13.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -13.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -13.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -13.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -12.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -12.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -12.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -12.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -12.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -12.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -12.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -12.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -12.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -12.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -12.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -12.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -12.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -12.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -12.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -12.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -12.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -12.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -12.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -12.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -11.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -11.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -11.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -11.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -11.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -11.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -11.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -11.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -11.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -11.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -11.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -11.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -11.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -11.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -11.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -11.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -11.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -11.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -11.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -11.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -10.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -10.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -10.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -10.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -10.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -10.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -10.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -10.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -10.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -10.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -10.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -10.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -10.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -10.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -10.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -10.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -10.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -10.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -10.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -10.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -09.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -09.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -09.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -09.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -09.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -09.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -09.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -09.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -09.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -09.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -09.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -09.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -09.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -09.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -09.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -09.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -09.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -09.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -09.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -09.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -08.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -08.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -08.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -08.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -08.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -08.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -08.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -08.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -08.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -08.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -08.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -08.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -08.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -08.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -08.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -08.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -08.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -08.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -08.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -08.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -07.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -07.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -07.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -07.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -07.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -07.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -07.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -07.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -07.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -07.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -07.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -07.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -07.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -07.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -07.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -07.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -07.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -07.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -07.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -07.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -06.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -06.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -06.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -06.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -06.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -06.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -06.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -06.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -06.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -06.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -06.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -06.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -06.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -06.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -06.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -06.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -06.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -06.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -06.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -06.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -05.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -05.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -05.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -05.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -05.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -05.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -05.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -05.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -05.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -05.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -05.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -05.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -05.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -05.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -05.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -05.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -05.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -05.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -05.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -05.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -04.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -04.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -04.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -04.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -04.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -04.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -04.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -04.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -04.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -04.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -04.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -04.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -04.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -04.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -04.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -04.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -04.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -04.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -04.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -04.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -03.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -03.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -03.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -03.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -03.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -03.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -03.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -03.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -03.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -03.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -03.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -03.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -03.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -03.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -03.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -03.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -03.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -03.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -03.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -03.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -02.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -02.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -02.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -02.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -02.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -02.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -02.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -02.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -02.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -02.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -02.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -02.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -02.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -02.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -02.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -02.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -02.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -02.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -02.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -02.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass -01.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass -01.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass -01.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass -01.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass -01.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass -01.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass -01.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass -01.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass -01.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass -01.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass -01.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass -01.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass -01.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass -01.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass -01.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass -01.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass -01.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass -01.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass -01.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass -01.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 000.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 000.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 000.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 000.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 000.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 000.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 000.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 000.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 000.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 000.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 000.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 000.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 000.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 000.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 000.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 000.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 000.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 000.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 000.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 000.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 001.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 001.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 001.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 001.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 001.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 001.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 001.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 001.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 001.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 001.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 001.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 001.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 001.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 001.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 001.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 001.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 001.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 001.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 001.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 001.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 002.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 002.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 002.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 002.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 002.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 002.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 002.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 002.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 002.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 002.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 002.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 002.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 002.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 002.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 002.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 002.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 002.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 002.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 002.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 002.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 003.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 003.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 003.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 003.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 003.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 003.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 003.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 003.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 003.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 003.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 003.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 003.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 003.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 003.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 003.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 003.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 003.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 003.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 003.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 003.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 004.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 004.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 004.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 004.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 004.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 004.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 004.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 004.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 004.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 004.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 004.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 004.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 004.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 004.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 004.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 004.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 004.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 004.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 004.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 004.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 005.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 005.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 005.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 005.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 005.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 005.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 005.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 005.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 005.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 005.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 005.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 005.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 005.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 005.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 005.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 005.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 005.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 005.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 005.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 005.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 006.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 006.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 006.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 006.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 006.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 006.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 006.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 006.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 006.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 006.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 006.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 006.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 006.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 006.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 006.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 006.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 006.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 006.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 006.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 006.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 007.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 007.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 007.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 007.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 007.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 007.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 007.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 007.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 007.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 007.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 007.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 007.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 007.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 007.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 007.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 007.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 007.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 007.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 007.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 007.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 008.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 008.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 008.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 008.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 008.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 008.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 008.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 008.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 008.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 008.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 008.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 008.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 008.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 008.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 008.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 008.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 008.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 008.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 008.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 008.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 009.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 009.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 009.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 009.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 009.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 009.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 009.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 009.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 009.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 009.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 009.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 009.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 009.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 009.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 009.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 009.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 009.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 009.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 009.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 009.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 010.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 010.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 010.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 010.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 010.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 010.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 010.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 010.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 010.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 010.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 010.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 010.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 010.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 010.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 010.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 010.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 010.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 010.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 010.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 010.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 011.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 011.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 011.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 011.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 011.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 011.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 011.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 011.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 011.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 011.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 011.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 011.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 011.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 011.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 011.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 011.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 011.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 011.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 011.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 011.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 012.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 012.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 012.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 012.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 012.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 012.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 012.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 012.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 012.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 012.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 012.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 012.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 012.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 012.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 012.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 012.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 012.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 012.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 012.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 012.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 013.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 013.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 013.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 013.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 013.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 013.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 013.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 013.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 013.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 013.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 013.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 013.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 013.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 013.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 013.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 013.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 013.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 013.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 013.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 013.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 014.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 014.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 014.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 014.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 014.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 014.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 014.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 014.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 014.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 014.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 014.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 014.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 014.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 014.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 014.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 014.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 014.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 014.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 014.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 014.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 015.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 015.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 015.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 015.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 015.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 015.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 015.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 015.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 015.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 015.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 015.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 015.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 015.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 015.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 015.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 015.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 015.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 015.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 015.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 015.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 016.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 016.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 016.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 016.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 016.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 016.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 016.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 016.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 016.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 016.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 016.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 016.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 016.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 016.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 016.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 016.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 016.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 016.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 016.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 016.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 017.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 017.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 017.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 017.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 017.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 017.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 017.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 017.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 017.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 017.
// VISUAL REVIEW NOTE: Let typography carry most of the visual hierarchy. Review pass 017.
// VISUAL REVIEW NOTE: Keep secondary labels muted but readable. Review pass 017.
// VISUAL REVIEW NOTE: Preserve comfortable tap targets on mobile. Review pass 017.
// VISUAL REVIEW NOTE: Keep primary content width close to a professional chat application. Review pass 017.
// VISUAL REVIEW NOTE: Avoid fake analytics and decorative metrics. Review pass 017.
// VISUAL REVIEW NOTE: Avoid marketing language inside the chat workspace. Review pass 017.
// VISUAL REVIEW NOTE: Keep upgrade messaging factual and compact. Review pass 017.
// VISUAL REVIEW NOTE: Keep settings rows scannable with one clear control. Review pass 017.
// VISUAL REVIEW NOTE: Keep destructive actions separated from ordinary preferences. Review pass 017.
// VISUAL REVIEW NOTE: Use consistent focus rings across controls. Review pass 017.
// VISUAL REVIEW NOTE: Use spacing to create hierarchy before adding decoration. Review pass 018.
// VISUAL REVIEW NOTE: Keep the chat canvas visually quiet around the composer. Review pass 018.
// VISUAL REVIEW NOTE: Avoid oversized empty hero cards. Review pass 018.
// VISUAL REVIEW NOTE: Avoid neon, glass, glow, and futuristic dashboard motifs. Review pass 018.
// VISUAL REVIEW NOTE: Use Cookie orange only where an action needs emphasis. Review pass 018.
// VISUAL REVIEW NOTE: Keep model controls compact and utility-oriented. Review pass 018.
// VISUAL REVIEW NOTE: Keep account controls anchored to the sidebar. Review pass 018.
// VISUAL REVIEW NOTE: Make mobile navigation feel like a product drawer, not a landing page. Review pass 018.
// VISUAL REVIEW NOTE: Use SVG line icons consistently. Review pass 018.
// VISUAL REVIEW NOTE: Use restrained corner radii and subtle borders. Review pass 018.
