# Cookie — Next.js + Cloudflare Workers

Cookie is a Next.js App Router frontend. This project is configured for Cloudflare Workers with the OpenNext adapter.

## Important

Do NOT use the Cloudflare Pages Direct Upload screen that says it cannot build TypeScript projects. That uploader is for already-built/static output.

Use one of these deployment paths:

### Option A — Cloudflare Workers + GitHub (recommended for this ZIP)

1. Put this project in a GitHub repository.
2. In Cloudflare, open **Workers & Pages**.
3. Create/import a Worker from the Git repository using Workers Builds.
4. Cloudflare will install dependencies and run the build/deploy configuration from this project.
5. The deploy script is:

   npm run deploy

### Option B — Local Wrangler

From this project folder:

   npm install
   npm run dev

Then deploy:

   npm run deploy

or:

   npx wrangler deploy

Wrangler/OpenNext builds the Next.js application before deploying it to Workers.

## Project structure

- app/page.tsx — Cookie application UI
- app/globals.css — complete design system and responsive styling
- app/layout.tsx — root layout and metadata
- open-next.config.ts — Cloudflare OpenNext adapter
- wrangler.jsonc — Workers deployment configuration
- next.config.ts — Next.js configuration

## Backend later

The frontend is intentionally separated from the model/backend layer. Later, API routes/server actions can connect Cookie to the server-side Ollama Cloud model without exposing provider credentials in the browser.
